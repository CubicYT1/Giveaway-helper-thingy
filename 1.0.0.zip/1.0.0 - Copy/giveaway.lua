print ("\ngiveaway  helper ver 1.0.0.")
print ("by cubic")
print ("commissioned by @yhandor")

--variables
tablecount = 0
users = {}
count = 1
wintext = " has won the giveaway!"
randomremovetext = " has been picked of... sorry!"

--random function
function random()
  if type(tablecount) == "number" then
  if tablecount > 0 then
  randomuser = math.random (1 , tablecount)
end
end
  end

--sequence
function start()
  print ("\nenter a command or type /commands")
  input = io.read()
  
  
  --/add
  if input == "/add" then
    print ("who to add?")
    users[tablecount + 1] = io.read()
    print (users[tablecount + 1] .. " has been added to the giveaway")
    tablecount = (tablecount + 1)
    
    
    --/show
  elseif input == "/show" then
    if tablecount == 0 then
      print ("nothing to show")
      else
       for show = 1 , tablecount do
         print (users[count] .. " (" .. count .. ")")
           count = (count + 1)
         end
         count = 1
       end
       
       
       --/remove
     elseif input == "/remove" then
       if tablecount == 0 then
         print ("nothing to remove")
       else
         print ("type the id of who to remove (to find it use /show) or type 0 to cancel")
           remove = io.read()
           if string.find (remove, "[%a%p%s]") then
             print ("can only contain numbers!")
             else
           if tonumber(remove) < 1 then
             print ("cancelled")
           elseif tonumber(remove) > tablecount then
             print ("invalid id")
           else
             print (users[tonumber(remove)] .. " has been removed from the giveaway")
             table.remove (users , tonumber(remove))
             tablecount = (tablecount - 1)
           end
         end
       end
       
       
       --/reset
     elseif input == "/reset" then
       if tablecount == 0 then
         print ("nothing to reset")
         else
       for reset = 1 , tablecount do
         table.remove(users , count)
         count = (count + 1)
       end
       count = 1
       tablecount = 0
       print ("reset complete!")
       end

       
       --/randomwinner
     elseif input == "/randomwinner" then
       if tablecount == 0 then
         print ("nobody to pick from")
         else
       print (users[randomuser] .. string.upper(wintext))
     end
     random()
     
     
     --/randomremove
   elseif input == "/randomremove" then
     if tablecount == 0 then
       print ("nothing to remove")
     else
       print (users[randomuser] .. randomremovetext)
       table.remove (users , randomuser)
       tablecount = (tablecount - 1)
       if tablecount == 1 then
         print (users[1] .. string.upper(wintext))
       end
     end
     
     
     --/commands
     elseif input == "/commands" then
       print ("/add - adds someone to the giveaway")
       print ("/remove - removes someone from the giveaway using the id found when using /show")
       print ("/show - shows everyone in the giveaway including the corresponding id")
       print ("/randomwinner - picks someone at random to win the giveaway")
       print ("/reset - removes everyone from the giveaway")
       print ("/randomremove - removes someone at random from the giveaway (if one remains after this they will win)")
       print ("/save - saves everyone in the giveaway into the save.txt file to be loaded later")
       print ("/load - loads your save from the save.txt file replacing everything")
       print ("/rrtext - edits the text shown upon someone being removed using /randomremove")
       print ("/rwtext - edits the text shown upon someone winning the giveaway")
       print ("/wip - shows all features being worked on")
       
       
       --/save
     elseif input == "/save" then
       if tablecount == 0 then
         print ("nothing to save")
         else
       file = io.open("save.txt" , "w")
       file:write(tablecount .. "\n")
       
      for savewrite = 1 , tablecount do
        file:write(users[count] .. "\n")
       count = (count +1)
     end
     
       count = 1
       print ("saved")
       file:close()
       end
       
       
       --/load
     elseif input == "/load" then
       if tablecount > 0 then
         for loadwipe = 1 , tablecount do
           table.remove (users , count)
           count = (count + 1)
         end
         count = 1
         tablecount = 0
       end
       
       file = io.open("save.txt" , "r")
       tablecount = tonumber(file:read())
       if tablecount == nil then
         tablecount = 0
         print ("Error loading file")
         else
for load = 1 , tablecount do
  users[count] = file:read("*line")
  count = (count + 1)
end
count = 1
print ("save loaded")
       file:close()
       end
       
       
       --/rwtext
     elseif input == "/rwtext" then
       print ("what would you like the win text to be")
       wintext = io.read()
       print ("win text changed to:")
       print ("[winner name]" .. wintext)
       
       
       --/rrtext
       elseif input == "/rrtext" then
        print ("what would you like the random remove text to be")
       randomremovetext = io.read()
       print ("random remove text changed to:")
       print ("[removed name]" .. randomremovetext)
       
       
     elseif input == "/wip" then
       print ("custom text saves coming in 1.1.0.")
       print ("twitch chat integration postponed to a later update")
       
     else
       print ("that is not a command")
       end
  random()
  start()
end

random()
start()